<!doctype html>
<html class="no-js" lang="zxx">
<head>
<meta charset="utf-8">
<meta http-equiv="x-ua-compatible" content="ie=edge">
<title><?php if(!empty($service['package_meta_title'])) { echo $service['package_meta_title']; } else { echo $default_seo['m_title']; }  ?></title>
<meta name="description" content="<?php if(!empty($service['package_meta_desc'])) { echo $service['package_meta_desc']; } else { $default_seo['m_dis']; }   ?>">
<meta name="keywords" content="<?php if(!empty($service['package_meta_key'])) { echo $service['package_meta_key']; } else { $default_seo['m_key']; }   ?>">

<link rel="canonical" href="<?php echo base_url(); ?>Services" />

<style>


</style>


<?php $this->load->view('user/includes/header'); ?>

<!--banner section start----->

<section class="banimg">


    <img src="<?php echo base_url(); ?>uploads/service/<?php echo $service['file']; ?>" class="loaded" data-was-processed="true">


    <div class="col-lg-12 inner_banner_text">

        <h1 class="inner_banner_text1"><?php echo $service['package_name']; ?></h1>

    </div>


</section>

<!--banner section end---->



<!--page content start---->
<div class="single-services py-lg-5 py-4 inner-padn" >

  <div class="container">

    <div class="row">
   
      <div class="col-lg-12 pc-show" ><a href="<?php echo base_url(); ?>Services/<?php echo  $service['package_parent_id']; ?>"> <img src="<?php echo base_url(); ?>assets/img/back.png" alt="" style="float: right;
    margin-top: -3%;
    border-radius: 50%;"> </a>    
    </div>
    
          <?php /*
          <div class="col-lg-8 det-img">
          <img src="<?php echo base_url(); ?>uploads/service/<?php echo $service['package_image']; ?>" alt="" style="float:left">    
          </div>
          */ ?>

      <div class="simple-text">
      
        <?php echo $service['package_desc']; ?>
        
      </div>

      
</div>

    </div>

  </div>

</div>							




<!---page content end---->




<?php $this->load->view('user/includes/footer'); ?>



</body>
</html>